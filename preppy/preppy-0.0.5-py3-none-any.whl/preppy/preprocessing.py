from multiprocessing import cpu_count, Pool
from typing import Callable, Optional, List

import numpy as np
import pandas as pd
from scipy.spatial.distance import cosine

cores = cpu_count()  # Number of CPU cores on your system


def create_keystring(row: pd.Series) -> str:
    """
    Create keystring for the row publisherid_itemid

    This is usefull to group the rows for the xgboost ranking. We want to do parewise ranking for element with the
    same keystring.

    :param row: row to process
    :return: keystring
    """
    return "_".join([str(int(row["publisher"])), str(int(row["itemsrc"]))])


def create_keystring_serie(df: pd.DataFrame) -> pd.Series:
    """
    Create the keystring for all element of the dataframe

    :param d: dataframe to apply the keystring function
    :return: Serie of keystring
    """
    return df.apply(create_keystring, axis=1)


def parallelize(
    data: pd.DataFrame, func: Callable[[pd.DataFrame], pd.Series], partitions: int
) -> pd.DataFrame:
    """
    Parallelize function to apply to dataframe

    :param data: big dataframe on which we want to apply the func
    :param func: func to apply
    :param partitions: number of partition to
    :return:
    """
    data_split = np.array_split(data, partitions)
    pool = Pool(cores)
    data = pd.concat(pool.map(func, data_split))
    pool.close()
    pool.join()
    return data


def select_final_features(
    df: pd.DataFrame,
    features: List[str],
    label: Optional[str] = None,
    partitions: int = 1,
) -> pd.DataFrame:
    """
    preprocess dataframe



    :param df: dataframe to process
    :param features: list of the feature columns
    :param label: name of label column if any
    :param partitions: int. number of partition to process df in parallel. By default no parallel computing
    :return: dataframe
    """
    # There is no need to parallelize the dataframe if there are not so many element (ie < 1000).
    # We just need for the training not the inference.
    if partitions > 1:
        df["keystring"] = parallelize(df, create_keystring_serie, partitions)
    else:
        df["keystring"] = df.apply(create_keystring, axis=1)

    df.set_index("keystring", inplace=True)

    if label:
        return df[features + [label]]
    else:
        return df[features]


def cosine_distance(v1: List[float], v2: List[float]) -> float:
    """
    Calculated cosine distance between two vectors (v1 and v2). The formula is the same as used for training i.e.:
    "The cosine distance between two points: cosineDistance(a,b) = 1 - (a dot b)/(norm(a) * norm(b))"

    :param v1: Array. Array of float of size N
    :param v2: Array. Array of float of size N
    :return: Return np.Nan if v1 and v2 are of different size else euclidean_distance of v1 and v2.
    """
    if v1 is None or v2 is None:
        return np.NaN
    elif len(v1) != len(v2):
        return np.NAN
    else:
        v1 = np.array(v1)
        v2 = np.array(v2)
        return cosine(v1, v2)


def create_distance_series(
    src_df: pd.DataFrame,
    dst_df: pd.DataFrame,
    col: str,
    dist_fun: Callable[[List[float], List[float]], float] = cosine_distance,
) -> pd.Series:
    """
    Compute the distance between the column ``col`` of the src and dst dataframe

    the src_df should just have one element containing the source article.
    the dst_df should contain all arcicle we want to rank for the src article.


    :param src_df: DataFrame. Pandas dataframe containing one row of itemsrc vector.
    :param dst_df: DataFrame. Pandas dataframe containing all itemdst vectors in one row each.
    :param col: String. Name of column for which distance is to be calculated
    :param dist_fun: function to use to compute the distance between the src and destination vectors
    :return: Series. Pandas series consisting of calculated distances.
    """
    assert len(src_df) == 1
    src_vector = src_df.at[0, col]
    dist_series = dst_df.apply(lambda row: dist_fun(src_vector, row[col]), axis=1)
    return dist_series
